// Global Variables
let accounts = [];
let currentAccount = null;
let accountCounter = 1;
let db = null;

// Social Media Platforms (75+ platforms)
const socialMediaPlatforms = [
    'Facebook', 'Instagram', 'Twitter/X', 'YouTube', 'LinkedIn', 'Pinterest', 'Snapchat', 'TikTok',
    'WhatsApp', 'WeChat', 'Telegram', 'Messenger', 'QQ', 'Reddit', 'Tumblr', 'VKontakte',
    'Flickr', 'Discord', 'Twitch', 'SoundCloud', 'Spotify', 'GitHub', 'Steam', 'Amazon',
    'eBay', 'Kindle', 'Goodreads', 'Duolingo', 'PayPal', 'Cash App', 'Venmo', 'Zelle',
    'Payoneer', 'Skrill', 'Netflix', 'Hulu', 'Disney+', 'HBO Max', 'Apple Music', 'Google Play Music',
    'TED Talk', 'Coursera', 'Udemy', 'Lynda', 'edX', 'Khan Academy', 'WordPress', 'Blogger',
    'Medium', 'Squarespace', 'Wix', 'Shopify', 'Etsy', 'Amazon Seller Central', 'Google My Business',
    'Yelp', 'TripAdvisor', 'Booking.com', 'Airbnb', 'Uber', 'Lyft', 'Google Maps', 'Apple Maps',
    'Waze', 'Foursquare', 'Swarm', 'Tinder', 'Bumble', 'Hinge', 'Grindr', 'Skype', 'Zoom',
    'Google Meet', 'Microsoft Teams', 'Slack', 'Trello', 'Jira', 'Asana', 'Microsoft Office 365',
    'Google Workspace', 'Dropbox', 'Google Drive', 'Microsoft OneDrive', 'iCloud'
];

// Random addresses for account generation
const randomAddresses = [
    '123 Main Street, New York, NY 10001, USA',
    '456 Oak Avenue, Los Angeles, CA 90210, USA',
    '789 Pine Road, Chicago, IL 60601, USA',
    '321 Elm Street, Houston, TX 77001, USA',
    '654 Maple Drive, Phoenix, AZ 85001, USA',
    '987 Cedar Lane, Philadelphia, PA 19101, USA',
    '147 Birch Boulevard, San Antonio, TX 78201, USA',
    '258 Willow Way, San Diego, CA 92101, USA',
    '369 Spruce Street, Dallas, TX 75201, USA',
    '741 Ash Avenue, San Jose, CA 95101, USA',
    '852 Poplar Place, Austin, TX 73301, USA',
    '963 Hickory Hill, Jacksonville, FL 32099, USA',
    '159 Walnut Way, Fort Worth, TX 76101, USA',
    '357 Cherry Circle, Columbus, OH 43085, USA',
    '468 Peach Path, Charlotte, NC 28201, USA',
    '579 Apple Alley, San Francisco, CA 94101, USA',
    '681 Orange Oval, Indianapolis, IN 46201, USA',
    '792 Grape Grove, Seattle, WA 98101, USA',
    '813 Berry Boulevard, Denver, CO 80201, USA',
    '924 Plum Place, Washington, DC 20001, USA'
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeDB();
    setupEventListeners();
    populatePlatformSelect();
    loadSettings();
    showPage('dashboard');
});

// IndexedDB Setup
function initializeDB() {
    const request = indexedDB.open('SocialMediaManager', 1);
    
    request.onerror = function(event) {
        console.error('Database error:', event.target.error);
        showToast('خطأ في قاعدة البيانات', 'error');
    };
    
    request.onsuccess = function(event) {
        db = event.target.result;
        loadAccounts();
    };
    
    request.onupgradeneeded = function(event) {
        db = event.target.result;
        
        // Create accounts object store
        const accountStore = db.createObjectStore('accounts', { keyPath: 'id' });
        accountStore.createIndex('name', 'name', { unique: false });
        accountStore.createIndex('platform', 'platform', { unique: false });
        
        // Create settings object store
        const settingsStore = db.createObjectStore('settings', { keyPath: 'key' });
    };
}

// Event Listeners Setup
function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const page = this.getAttribute('data-page');
            showPage(page);
        });
    });
    
    // Search and filter
    document.getElementById('search-input').addEventListener('input', filterAccounts);
    document.getElementById('platform-filter').addEventListener('change', filterAccounts);
    
    // Add account form
    document.getElementById('add-account-form').addEventListener('submit', handleAddAccount);
    
    // Modal close
    document.getElementById('account-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    
    // Settings
    document.getElementById('default-prefix').addEventListener('change', saveSettings);
    document.getElementById('auto-generate-passwords').addEventListener('change', saveSettings);
    document.getElementById('encrypt-data').addEventListener('change', saveSettings);
}

// Page Navigation
function showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show selected page
    document.getElementById(pageId).classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-page="${pageId}"]`).classList.add('active');
    
    // Load page-specific data
    if (pageId === 'dashboard') {
        updateStats();
        displayAccounts();
    }
}

// Populate Platform Select
function populatePlatformSelect() {
    const platformSelect = document.getElementById('platform');
    const platformFilter = document.getElementById('platform-filter');
    
    socialMediaPlatforms.forEach(platform => {
        const option = document.createElement('option');
        option.value = platform;
        option.textContent = platform;
        platformSelect.appendChild(option);
        
        const filterOption = document.createElement('option');
        filterOption.value = platform;
        filterOption.textContent = platform;
        platformFilter.appendChild(filterOption);
    });
}

// Account Management
function handleAddAccount(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const accountData = {
        id: generateUUID(),
        name: document.getElementById('account-name').value || generateAccountName(),
        platform: document.getElementById('platform').value,
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        email: document.getElementById('email').value,
        emailPassword: document.getElementById('email-password').value,
        sessionId: document.getElementById('session-id').value,
        recoveryEmail: document.getElementById('recovery-email').value,
        phone: document.getElementById('phone').value,
        twoFactor: document.getElementById('two-factor').value,
        randomAddress: document.getElementById('random-address').value || getRandomAddress(),
        notes: document.getElementById('notes').value,
        creationDate: new Date().toISOString(),
        lastLoginDate: null,
        status: 'inactive'
    };
    
    // Encrypt sensitive data if enabled
    if (document.getElementById('encrypt-data').checked) {
        accountData.password = btoa(accountData.password);
        accountData.emailPassword = btoa(accountData.emailPassword);
    }
    
    saveAccount(accountData);
}

function saveAccount(accountData) {
    const transaction = db.transaction(['accounts'], 'readwrite');
    const store = transaction.objectStore('accounts');
    
    store.add(accountData).onsuccess = function() {
        accounts.push(accountData);
        accountCounter++;
        showToast('تم إنشاء الحساب بنجاح');
        resetForm();
        showPage('dashboard');
    };
    
    transaction.onerror = function() {
        showToast('خطأ في حفظ الحساب', 'error');
    };
}

function loadAccounts() {
    const transaction = db.transaction(['accounts'], 'readonly');
    const store = transaction.objectStore('accounts');
    
    store.getAll().onsuccess = function(event) {
        accounts = event.target.result;
        accountCounter = accounts.length + 1;
        updateStats();
        displayAccounts();
    };
}

function displayAccounts() {
    const tbody = document.getElementById('accounts-tbody');
    const emptyState = document.getElementById('empty-state');
    
    if (accounts.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }
    
    emptyState.style.display = 'none';
    
    tbody.innerHTML = accounts.map(account => `
        <tr>
            <td>${account.name}</td>
            <td>${account.platform}</td>
            <td>${account.username}</td>
            <td>${new Date(account.creationDate).toLocaleDateString('ar-SA')}</td>
            <td><span class="status-badge status-${account.status}">${account.status === 'active' ? 'نشط' : 'غير نشط'}</span></td>
            <td>
                <button class="action-btn" onclick="viewAccount('${account.id}')">عرض</button>
                <button class="action-btn" onclick="editAccount('${account.id}')">تعديل</button>
                <button class="action-btn danger" onclick="deleteAccount('${account.id}')">حذف</button>
                <button class="action-btn" onclick="loginToAccount('${account.id}')">تسجيل دخول</button>
            </td>
        </tr>
    `).join('');
}

function filterAccounts() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const platformFilter = document.getElementById('platform-filter').value;
    
    const filteredAccounts = accounts.filter(account => {
        const matchesSearch = account.name.toLowerCase().includes(searchTerm) ||
                            account.username.toLowerCase().includes(searchTerm) ||
                            account.platform.toLowerCase().includes(searchTerm);
        
        const matchesPlatform = !platformFilter || account.platform === platformFilter;
        
        return matchesSearch && matchesPlatform;
    });
    
    // Update display with filtered accounts
    const tbody = document.getElementById('accounts-tbody');
    tbody.innerHTML = filteredAccounts.map(account => `
        <tr>
            <td>${account.name}</td>
            <td>${account.platform}</td>
            <td>${account.username}</td>
            <td>${new Date(account.creationDate).toLocaleDateString('ar-SA')}</td>
            <td><span class="status-badge status-${account.status}">${account.status === 'active' ? 'نشط' : 'غير نشط'}</span></td>
            <td>
                <button class="action-btn" onclick="viewAccount('${account.id}')">عرض</button>
                <button class="action-btn" onclick="editAccount('${account.id}')">تعديل</button>
                <button class="action-btn danger" onclick="deleteAccount('${account.id}')">حذف</button>
                <button class="action-btn" onclick="loginToAccount('${account.id}')">تسجيل دخول</button>
            </td>
        </tr>
    `).join('');
}

function viewAccount(accountId) {
    const account = accounts.find(acc => acc.id === accountId);
    if (!account) return;
    
    currentAccount = account;
    
    const modalBody = document.getElementById('modal-body');
    modalBody.innerHTML = `
        <div class="detail-item">
            <span class="detail-label">اسم الحساب:</span>
            <span class="detail-value">${account.name}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.name}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">المنصة:</span>
            <span class="detail-value">${account.platform}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.platform}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">اسم المستخدم:</span>
            <span class="detail-value">${account.username}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.username}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">كلمة المرور:</span>
            <span class="detail-value">••••••••</span>
            <button class="copy-btn" onclick="copyPassword('${account.id}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">البريد الإلكتروني:</span>
            <span class="detail-value">${account.email || 'غير محدد'}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.email}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">معرف الجلسة:</span>
            <span class="detail-value">${account.sessionId || 'غير محدد'}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.sessionId}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">بريد الاسترداد:</span>
            <span class="detail-value">${account.recoveryEmail || 'غير محدد'}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.recoveryEmail}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">رقم الهاتف:</span>
            <span class="detail-value">${account.phone || 'غير محدد'}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.phone}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">العنوان العشوائي:</span>
            <span class="detail-value">${account.randomAddress || 'غير محدد'}</span>
            <button class="copy-btn" onclick="copyToClipboard('${account.randomAddress}')">نسخ</button>
        </div>
        <div class="detail-item">
            <span class="detail-label">تاريخ الإنشاء:</span>
            <span class="detail-value">${new Date(account.creationDate).toLocaleString('ar-SA')}</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">ملاحظات:</span>
            <span class="detail-value">${account.notes || 'لا توجد ملاحظات'}</span>
        </div>
    `;
    
    document.getElementById('modal-title').textContent = `تفاصيل الحساب: ${account.name}`;
    document.getElementById('account-modal').style.display = 'block';
}

function editAccount(accountId) {
    // Implementation for editing account
    showToast('ميزة التعديل قيد التطوير');
}

function deleteAccount(accountId) {
    if (!confirm('هل أنت متأكد من حذف هذا الحساب؟')) return;
    
    const transaction = db.transaction(['accounts'], 'readwrite');
    const store = transaction.objectStore('accounts');
    
    store.delete(accountId).onsuccess = function() {
        accounts = accounts.filter(acc => acc.id !== accountId);
        displayAccounts();
        updateStats();
        showToast('تم حذف الحساب بنجاح');
    };
}

function loginToAccount(accountId) {
    const account = accounts.find(acc => acc.id === accountId);
    if (!account) return;
    
    // Update last login date
    account.lastLoginDate = new Date().toISOString();
    account.status = 'active';
    
    const transaction = db.transaction(['accounts'], 'readwrite');
    const store = transaction.objectStore('accounts');
    
    store.put(account).onsuccess = function() {
        displayAccounts();
        updateStats();
        showToast(`تم تسجيل الدخول إلى ${account.name} على ${account.platform}`);
    };
}

// Utility Functions
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function generateAccountName() {
    const prefix = document.getElementById('default-prefix').value || 'KMF';
    return `${prefix} ${accountCounter}`;
}

function getRandomAddress() {
    return randomAddresses[Math.floor(Math.random() * randomAddresses.length)];
}

function generateRandomAddress() {
    document.getElementById('random-address').value = getRandomAddress();
}

function generatePassword(inputId) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 12; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    document.getElementById(inputId).value = password;
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
}

function copyToClipboard(text) {
    if (!text) return;
    
    navigator.clipboard.writeText(text).then(() => {
        showToast('تم نسخ النص');
    }).catch(() => {
        showToast('فشل في نسخ النص', 'error');
    });
}

function copyPassword(accountId) {
    const account = accounts.find(acc => acc.id === accountId);
    if (!account) return;
    
    let password = account.password;
    
    // Decrypt if encrypted
    if (document.getElementById('encrypt-data').checked) {
        try {
            password = atob(password);
        } catch (e) {
            showToast('خطأ في فك تشفير كلمة المرور', 'error');
            return;
        }
    }
    
    copyToClipboard(password);
}

function resetForm() {
    document.getElementById('add-account-form').reset();
    document.getElementById('random-address').value = '';
}

function closeModal() {
    document.getElementById('account-modal').style.display = 'none';
    currentAccount = null;
}

function updateStats() {
    document.getElementById('total-accounts').textContent = accounts.length;
    document.getElementById('active-sessions').textContent = accounts.filter(acc => acc.status === 'active').length;
}

// Settings Management
function loadSettings() {
    if (!db) return;
    
    const transaction = db.transaction(['settings'], 'readonly');
    const store = transaction.objectStore('settings');
    
    store.getAll().onsuccess = function(event) {
        const settings = event.target.result;
        settings.forEach(setting => {
            const element = document.getElementById(setting.key);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = setting.value;
                } else {
                    element.value = setting.value;
                }
            }
        });
    };
}

function saveSettings() {
    const settings = [
        { key: 'default-prefix', value: document.getElementById('default-prefix').value },
        { key: 'auto-generate-passwords', value: document.getElementById('auto-generate-passwords').checked },
        { key: 'encrypt-data', value: document.getElementById('encrypt-data').checked }
    ];
    
    const transaction = db.transaction(['settings'], 'readwrite');
    const store = transaction.objectStore('settings');
    
    settings.forEach(setting => {
        store.put(setting);
    });
    
    showToast('تم حفظ الإعدادات');
}

// Data Management
function exportData() {
    const data = {
        accounts: accounts,
        exportDate: new Date().toISOString(),
        version: '1.0'
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `social-media-accounts-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    URL.revokeObjectURL(url);
    showToast('تم تصدير البيانات بنجاح');
}

function importData() {
    document.getElementById('import-file').click();
}

function handleImport(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            if (data.accounts && Array.isArray(data.accounts)) {
                const transaction = db.transaction(['accounts'], 'readwrite');
                const store = transaction.objectStore('accounts');
                
                data.accounts.forEach(account => {
                    account.id = generateUUID(); // Generate new IDs to avoid conflicts
                    store.add(account);
                });
                
                transaction.oncomplete = function() {
                    loadAccounts();
                    showToast(`تم استيراد ${data.accounts.length} حساب بنجاح`);
                };
            } else {
                showToast('ملف البيانات غير صحيح', 'error');
            }
        } catch (error) {
            showToast('خطأ في قراءة الملف', 'error');
        }
    };
    
    reader.readAsText(file);
}

function clearAllData() {
    if (!confirm('هل أنت متأكد من حذف جميع البيانات؟ هذا الإجراء لا يمكن التراجع عنه.')) return;
    
    const transaction = db.transaction(['accounts'], 'readwrite');
    const store = transaction.objectStore('accounts');
    
    store.clear().onsuccess = function() {
        accounts = [];
        accountCounter = 1;
        displayAccounts();
        updateStats();
        showToast('تم حذف جميع البيانات');
    };
}

// Toast Notifications
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    document.getElementById('toast-container').appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Loading Overlay
function showLoading() {
    document.getElementById('loading').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}

